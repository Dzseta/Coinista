const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const localStrategy = require('passport-local').Strategy;
const expressSession = require('express-session');
const passport = require('passport');
const path = require('path');

const app = express();

const dbUrl = 'mongodb+srv://dzseta:progrendfejlmongo@progrendfejl.xsmazas.mongodb.net/?retryWrites=true&w=majority';

mongoose.connect(dbUrl);
const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', function () {
  console.log('Connected to MongoDB successfully!');
});

// szukseges semak
require('./userSchema');
require('./coinSchema');
require('./bootstrapper')();

const User = mongoose.model('user');
const Coin = mongoose.model('coin');

app.use(expressSession({ secret: 'prf2023', resave: true, saveUninitialized: true }));

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

const corsOptions = {
    origin: 'http://localhost:4200',
    optionsSuccessStatus: 200,
    credentials: true
};
app.use(cors(corsOptions));
app.use(express.static(path.join(__dirname, 'public')));


// login
passport.use('local', new localStrategy(async function(username, password, done) {
    try {
        const user = await User.findOne({ username: username });
        if (!user) return done(null, false, { message: 'Felhasználó nem található!' });
        user.comparePassword(password, function(error, isMatch) {
            if (error) return done(error, false);
            if(!isMatch) return done(null, false, { message: 'Hibás jelszó!' });
            return done(null, isMatch);
        });
    } catch (err) {
        return done('Hiba', null);
    }
}));

passport.serializeUser(function (user, done) {
if (!user) return done('Nincs megadva beléptethető felhasználó.', null);
return done(null, user);
});

passport.deserializeUser(function (user, done) {
if (!user) return done("Nincs kiléptethető felhasználó.", null);
return done(null, user);
});

app.use(passport.initialize());
app.use(passport.session());

app.get('/', (req, res, next) => {
    res.send('Hello World!!')
});

app.use((req, res, next) => {
    console.log('A middleware futott!')
    next()
})

app.use('/', require('./routes'))

app.use((req, res, next) => {
    res.status(404).sendFile(path.join(__dirname, 'public', 'index.html'));

})

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000')
})