const mongoose = require('mongoose');

const coinSchema = new mongoose.Schema({
  id: {
    type: Number,
    required: true,
  },
  value: {
    type: Number,
    required: true,
  },
  currency: {
    type: String,
    required: true,
  },
  country: {
    type: String,
    required: true,
  },
  year: {
    type: Number,
    required: true,
    default: 0,
  },
}, {collection: 'coin'});

const Coin = mongoose.model('coin', coinSchema);

module.exports = Coin;