const express = require('express')
const router = express.Router();
const passport = require('passport');
const mongoose = require('mongoose');

const User = mongoose.model('user');
const Coin = mongoose.model('coin');

// login
router.route('/login').post((req, res, next) => {
  if (req.body.username, req.body.password) {
    passport.authenticate('local', function(error, user) {
      if(error) return res.status(500).send(error);
      req.login(user, function(error) {
        if(error) return res.status(500).send(error);
        return res.status(200).send('Sikeres bejelentkezés!');
      });
    })(req, res);
  } else {
    return res.status(400).send('Hiba');
  }
});

// logout
router.route('/logout').post((req, res, next) => {
  if(req.isAuthenticated()) {
    req.logout();
    return res.status(200).send('Sikeres kijelentkezés!');
  } else {
    return res.status(400).send('Sikertelen kijelentkezés!');
  }
});

// user status
router.route('/status').get((req, res, next) => {
  if(req.isAuthenticated()) {
    return res.status(200).send(req.session.passport);
  }else {
    return res.status(403).send('Nincs bejelentkezett felhasználó!');
  }
});

// get users
router.route('/user')
  .get((req, res, next) => {
    User.find({})
        .then((users) => {
            res.status(200).send(users);
        })
        .catch((err) => {
            res.status(500).send('Hiba!');
        });
})  

// register
router.route('/useradd')
.post((req, res, next) => {
  if(req.body.username && req.body.email  && req.body.password){
    User.findOne({username: req.body.username})
      .then((user) => {
        if(user){
                return res.status(400).send('Foglalt felhasználónév!');
        }else{
            const user = new User({
                username: req.body.username,
                email: req.body.email,
                password: req.body.password,
            })
            user.save()
                .then(() => {
                    res.status(202).send('Sikeres regisztráció!');
                })
                .catch((err) => {
                  console.error(err);
                  return res.status(500).send('Hiba');
                })
          }
      })
      .catch((err) => {
          return res.status(500).send('Hiba');
      })
  }else{
      return res.status(400).send('Hiba');
  }
});

// update user
router.route('/user/:username')
.put((req, res, next) => {
  if (req.body.accesLevel) {
    User.findOneAndUpdate({ username: req.params.username }, {
        admin: 1,
    })
      .then((user) => {
        if (!user) {
            return res.status(404).send('Felhasználó nem található!');
        }
        res.status(200).send('Felhasználó sikeresen frissítve!');
      })
      .catch((err) => {
        console.error(err);
        res.status(500).send('Hiba');
      });
  } else {
    res.status(400).send('Hiba');
  }
});

// delete user
router.route('/user/:username')
.delete((req, res, next) => {
  User.findOneAndDelete({ username: req.params.username })
    .then((user) => {
      if (!user) {
        return res.status(404).send('Felhasználó nem található!');
      }
      res.status(200).send('Sikeres törlés!');
    })
    .catch((err) => {
      console.error(err);
      res.status(500).send('Hiba!');
    });
});

// get user
router.route('/user/:username')
  .get((req, res, next) => {
    User.findOne({ username: req.params.username })
      .then((user) => {
        if (!user) {
          return res.status(404).send('Felhasználó nem található!');
        }
        return res.status(200).send(user);
      })
      .catch((err) => {
        return res.status(500).send('Hiba');
      });
});

// coins
router.route('/coins')
  .get((req, res, next) => {
    Coin.find({})
      .then((coins) => {
        res.status(200).send(coins);
      })
      .catch((err) => {
        res.status(500).send('Hiba');
      });
  }).post((req, res, next) => {
    if(req.body.id && req.body.value  && req.body.currency  && req.body.country && req.body.year){
        Coin.findOne({id: req.body.id})
            .then((coin) => {
                if(coin){
                    return res.status(400).send('Létező ID');
                }else{
                    const coin = new Coin({
                        id: req.body.id,
                        value: req.body.value,
                        currency: req.body.currency,
                        country: req.body.country,
                        year: req.body.year,
                    })
                    coin.save()
                        .then(() => {
                            res.status(202).send('Sikeres létrehozás!');
                        })
                        .catch((err) => {
                          console.error(err);
                          return res.status(500).send('Hiba!');
                        })
                }
            })
            .catch((err) => {
                return res.status(500).send('Hiba');
            })
    }else{
        return res.status(400).send('Hiba');
    }
});

// get coin
router.route('/coins/:id')
.put((req, res, next) => {
  Coin.findOneAndUpdate({ id: req.params.id }, { $set: req.body }, { new: true })
  .then((coin) => {
    if(coin){
      res.status(200).json(coin);
    }else{
      res.status(404).send('Hiba');
    }
  })
  .catch((err) => {
    return res.status(500).send('Hiba');
  });
});

// delete coin
router.route('/coins/:id')
.delete((req, res, next) => {
  Coin.findOneAndDelete({ id: req.params.id })
    .then((coin) => {
      if (!coin) {
        return res.status(404).send('Érme nem találva!');
      }
      res.status(200).send('Sikeres törlés!');
    })
    .catch((err) => {
      console.error(err);
      res.status(500).send('Hiba!');
    });
});

module.exports = router;