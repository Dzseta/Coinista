const mongoose = require('mongoose');
const User = mongoose.model('user');

async function ensureAdminExists() {
  try {
    // Ellenőrizzük, van-e már admin felhasználó az adatbázisban
    const admin = await User.findOne({ admin: 1 });
    if (admin) { 
      console.log('Az admin felhasználó már megtalálható az adatbázisban!');
    } else {
      // Ha nincs, akkor létrehozunk egy újat
      const newAdmin = new User({
        username: 'admin',
        email: 'admin@admin.hu',
        password: 'admin123',
        admin: 1
      });
      await newAdmin.save();
      console.log('Az admin felhasználó sikeresen létrehozva!');
    }
  } catch (error) {
    console.error('Hiba történt az admin ellenőrzése vagy létrehozása során: ', error);
  }
}

module.exports = ensureAdminExists;