export interface Coin {
    id: number;
    value: number;
    currency: string;
    country: string;
    year: number;
}