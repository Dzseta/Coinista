import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private http: HttpClient) { }

  register(usernames: string, email: string, password: string){
    return this.http.post(environment.baseUrl + 'user', { username: usernames, email: email, password: password }, {responseType: 'text'});
  }
}
