import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private readonly apiUrl = 'http://localhost:3000/user';
  private readonly apiUrlAdmin = 'http://localhost:3000/useradd';

  constructor(private http: HttpClient) { }

  public getUsers(): Observable<User[]> {
    return this.http.get<User[]>(this.apiUrl);
  }

  public createUser(user: User): Observable<User> {
    return this.http.post<User>(this.apiUrlAdmin, user);
  }
  
  public updateUser(username: string, user: User) {
    return this.http.put(`${this.apiUrl}/${username}`,user);
  }

  public deleteUser(username: string): Observable<User> {
    return this.http.delete<User>(`${this.apiUrl}/${username}`);
  }

  public getUser(username: string): Observable<User> {
    return this.http.get<User>(`${this.apiUrl}/${username}`);
  }
}
