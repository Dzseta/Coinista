import { Injectable } from '@angular/core';
import { Coin } from '../models/coin';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CoinService {
  private url = 'http://localhost:3000/coins';

  constructor(private http: HttpClient) { }

  getCoins(): Observable<Coin[]> {
    return this.http.get<Coin[]>(this.url);
  }

  createCoin(coin: Coin): Observable<any> {
    return this.http.post<any>(this.url, coin);
  }

  updateCoin(coinId: string, coin: Coin) {
    return this.http.put(`${this.url}/${coinId}`,coin);
  }

  deleteCoin(coinId: string): Observable<any> {
    return this.http.delete<Coin>(`${this.url}/${coinId}`);
  }

  getCoin(coinId: string): Observable<Coin> {
    return this.http.get<Coin>(`${this.url}/${coinId}`);
  }
}
