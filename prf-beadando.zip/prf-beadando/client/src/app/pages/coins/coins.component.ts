import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Coin } from 'src/app/shared/models/coin';
import { CoinService } from 'src/app/shared/services/coin.service';

@Component({
  selector: 'app-coins',
  templateUrl: './coins.component.html',
  styleUrls: ['./coins.component.scss']
})
export class CoinsComponent implements OnInit {

  collectionName = 'Coins';
  displayedColumns: string[] = ['value', 'currency', 'country', 'year'];
  data: Coin[] = [];
  dataSource!: MatTableDataSource<Coin>;
  form: FormGroup = new FormGroup ({
    id: new FormControl(),
    value: new FormControl(),
    currency: new FormControl(),
    country: new FormControl(),
    year: new FormControl()
  });

  getSub?: Subscription;
  sortSub?: Subscription;

  @ViewChild(MatSort) sort!: MatSort;

  constructor(private coinService: CoinService, private router: Router) { }

  ngOnInit() {
    this.dataSource = new MatTableDataSource(this.data);
    this.get();
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.sort.sortChange.subscribe(() => {
      this.getSub?.unsubscribe();
      this.get()
    });
  }

  ngOnDestroy(): void {
    this.getSub?.unsubscribe();
    this.sortSub?.unsubscribe();
  }

  get() {
    this.coinService.getCoins().subscribe(
      (response: Coin[]) => {
        this.data = response;
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
