import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coindetail',
  templateUrl: './coindetail.component.html',
  styleUrls: ['./coindetail.component.scss']
})
export class CoindetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
