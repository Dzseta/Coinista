import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../../shared/services/register.service';
import { AbstractControl, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { UserService } from 'src/app/shared/services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  minPw = 8;
  signupForm!: FormGroup;

  constructor(private registerService: RegisterService, private userService: UserService, private router: Router) {}

  ngOnInit(): void {
    this.signupForm = new FormGroup({
      username: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(this.minPw)]),
      passwordRe: new FormControl('', [Validators.required]),
      terms: new FormControl('', [Validators.required])
    });
    this.signupForm.addValidators([this.passwordMatchValidator]);
  }

  onSubmit() {
    if (!this.validateForm()) return;

    /*if(this.userService.getUser(this.signupForm.get('username')?.value) != null) {
      console.log(this.userService.getUser(this.signupForm.get('username')?.value));
      this.signupForm.get('username')!.setErrors({'usedUsername': true});
      return;
    } */
    this.registerService.register(this.signupForm.get('username')?.value, this.signupForm.get('email')?.value, this.signupForm.get('password')?.value)
      .subscribe(
        (msg: any) => {
          console.log(msg);
          this.router.navigate(['/login']);
        }, (error: any) => {
          console.log(error);
        })
  }

  onPasswordInput() {
    if (this.signupForm.hasError('passwordMismatch')) {
        this.signupForm.get('passwordRe')!.setErrors({'passwordMismatch': true});
    } else {
        this.signupForm.get('passwordRe')!.setErrors(null);
    }
  }

  public passwordMatchValidator: ValidatorFn = (formGroup: AbstractControl): ValidationErrors | null => {
    return this.signupForm.get('password')!.value === this.signupForm.get('passwordRe')!.value ?
      null : { 'passwordMismatch': true };
  };

  validateForm() {
    var valid = true;
    valid = valid && this.signupForm.get('username')!.valid;
    valid = valid && this.signupForm.get('email')!.valid;
    valid = valid && this.signupForm.get('password')!.valid;
    valid = valid && this.signupForm.get('passwordRe')!.valid;
    valid = valid && this.signupForm.get('terms')!.valid;
    return valid;
  }

}
