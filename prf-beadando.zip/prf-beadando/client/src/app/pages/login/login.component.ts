import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './../../shared/services/login.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  
  loginForm!: FormGroup;

  constructor(private loginService: LoginService, private router: Router) {}

  public ngOnInit() {
    this.loginForm = new FormGroup({
      username: new FormControl('', { validators: [Validators.required] }),
      password: new FormControl('', { validators: [Validators.required] })
    });
    if(localStorage.getItem('user')) {
      localStorage.removeItem('user');
      this.loginService.logout().subscribe(msg => {
          console.log(msg);
        }, error => {
          console.log(error);
        }
      );
    }
  }

  onSubmit() {
    this.loginService.login(this.loginForm.get('username')?.value, this.loginForm.get('password')?.value).subscribe(msg => {
      console.log(msg);
      localStorage.setItem('user', this.loginForm.get('username')?.value);
      this.router.navigate(['']);
    }, error => {
      console.log(error);
    });
  }

}
