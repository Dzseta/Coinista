import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/shared/models/user';
import { LoginService } from 'src/app/shared/services/login.service';
import { UserService } from 'src/app/shared/services/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  user: User | undefined;
  userString: string | null = localStorage.getItem('user');
  loggedInUser: User | undefined;

  admin: number = 0;
  loggedIn: boolean = false;

  constructor(private router: Router, private userService: UserService, private loginService: LoginService) { }

  ngOnInit(): void {
    if (this.userString) {
      const username = this.userString;
      this.userService.getUser(username).subscribe(
        (user) => {
          this.loggedInUser = user;
          this.admin = this.loggedInUser.admin;
          this.loggedIn = true;
        },
        (error) => console.log(error)
      );
    }
  }

  logout() {
    localStorage.removeItem('user');
      this.loginService.logout().subscribe(msg => {
        }, error => {
          console.log("hiba kilepeskor");
        }
      );
      this.router.navigate(['']);
  }
}
