import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthguardGuard } from './shared/services/authguard.guard';
import { CoinsComponent } from './pages/coins/coins.component';
import { CoindetailComponent } from './pages/coindetail/coindetail.component';
import { LoginComponent } from './pages/login/login.component';
import { HomeComponent } from './pages/home/home.component';
import { ErrorComponent } from './pages/error/error.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { RegisterComponent } from './pages/register/register.component';
import { AdminComponent } from './pages/admin/admin.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent, 
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'register',
    component: RegisterComponent,
  },
  {
    path: 'profile',
    component: ProfileComponent,
    canActivate: [AuthguardGuard]
  },
  {
    path: 'coins',
    component: CoinsComponent,
  },
  {
    path: 'error',
    component: ErrorComponent,
  },
  {
    path: 'coinsdetail/:id',
    component: CoindetailComponent,
  },
  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [AuthguardGuard]
  },
  { 
    path: '',
    redirectTo: '/main',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: 'error',
    pathMatch: 'full'
  }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
